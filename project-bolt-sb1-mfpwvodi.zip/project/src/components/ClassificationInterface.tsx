import React, { useState, useCallback } from 'react';
import { Upload, Image as ImageIcon, Brain, CheckCircle, BarChart3, Download } from 'lucide-react';

const ClassificationInterface: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isClassifying, setIsClassifying] = useState(false);
  const [results, setResults] = useState<any>(null);

  const riceTypes = [
    'Basmati', 'Jasmine', 'Arborio', 'Brown Rice', 'Wild Rice', 
    'Sushi Rice', 'Long Grain', 'Medium Grain', 'Short Grain',
    'Red Rice', 'Black Rice', 'Sticky Rice'
  ];

  const handleImageUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage(e.target?.result as string);
        setResults(null);
      };
      reader.readAsDataURL(file);
    }
  }, []);

  const simulateClassification = useCallback(() => {
    if (!selectedImage) return;

    setIsClassifying(true);
    
    // Simulate processing time
    setTimeout(() => {
      const predictions = riceTypes.map(type => ({
        type,
        confidence: Math.random() * 100,
      })).sort((a, b) => b.confidence - a.confidence);

      setResults({
        predictions: predictions.slice(0, 5),
        processingTime: (Math.random() * 2 + 0.5).toFixed(2),
        modelAccuracy: 96.4,
      });
      setIsClassifying(false);
    }, 2500);
  }, [selectedImage]);

  return (
    <section className="py-12 min-h-screen">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Rice Classification Interface
          </h1>
          <p className="text-xl text-gray-600">
            Upload an image of rice grains to identify the variety using our AI model
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Upload Section */}
          <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <Upload className="w-6 h-6 mr-3 text-orange-500" />
                Upload Rice Image
              </h3>

              <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-orange-400 transition-colors duration-300">
                {selectedImage ? (
                  <div className="space-y-4">
                    <img
                      src={selectedImage}
                      alt="Selected rice"
                      className="max-w-full max-h-64 mx-auto rounded-lg shadow-lg"
                    />
                    <p className="text-sm text-gray-600">Image uploaded successfully</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <ImageIcon className="w-16 h-16 mx-auto text-gray-400" />
                    <div>
                      <p className="text-lg font-medium text-gray-700">
                        Drag and drop your rice image here
                      </p>
                      <p className="text-sm text-gray-500">
                        or click to browse files
                      </p>
                    </div>
                  </div>
                )}
                
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
              </div>

              <button
                onClick={simulateClassification}
                disabled={!selectedImage || isClassifying}
                className="w-full mt-6 bg-gradient-to-r from-orange-500 to-green-600 text-white px-8 py-4 rounded-xl font-semibold text-lg disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg transition-all duration-300 flex items-center justify-center space-x-2"
              >
                {isClassifying ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Classifying...</span>
                  </>
                ) : (
                  <>
                    <Brain className="w-5 h-5" />
                    <span>Classify Rice Type</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Results Section */}
          <div className="space-y-6">
            {results ? (
              <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
                <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                  <BarChart3 className="w-6 h-6 mr-3 text-green-500" />
                  Classification Results
                </h3>

                <div className="space-y-6">
                  {/* Top Prediction */}
                  <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-6 border border-green-200">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-xl font-bold text-green-800">
                        {results.predictions[0].type}
                      </h4>
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    </div>
                    <div className="text-lg font-semibold text-green-700">
                      {results.predictions[0].confidence.toFixed(1)}% Confidence
                    </div>
                  </div>

                  {/* Other Predictions */}
                  <div className="space-y-3">
                    <h5 className="font-semibold text-gray-700">Other possibilities:</h5>
                    {results.predictions.slice(1).map((pred: any, index: number) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <span className="font-medium text-gray-700">{pred.type}</span>
                        <div className="flex items-center space-x-3">
                          <div className="w-24 bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-orange-500 h-2 rounded-full transition-all duration-1000"
                              style={{ width: `${pred.confidence}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium text-gray-600 w-12">
                            {pred.confidence.toFixed(1)}%
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-200">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-orange-600">
                        {results.processingTime}s
                      </div>
                      <div className="text-sm text-gray-600">Processing Time</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">
                        {results.modelAccuracy}%
                      </div>
                      <div className="text-sm text-gray-600">Model Accuracy</div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
                <div className="text-center py-12">
                  <Brain className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                  <h3 className="text-xl font-medium text-gray-500 mb-2">
                    Ready for Classification
                  </h3>
                  <p className="text-gray-400">
                    Upload an image to see the AI classification results
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ClassificationInterface;