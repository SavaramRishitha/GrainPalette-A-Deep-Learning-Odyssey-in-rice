import React from 'react';
import { ArrowRight, Brain, Database, Image, Cpu, Smartphone } from 'lucide-react';

interface HeroProps {
  setActiveSection: (section: string) => void;
}

const Hero: React.FC<HeroProps> = ({ setActiveSection }) => {
  const stats = [
    { label: 'Rice Varieties', value: '12+', icon: Database },
    { label: 'Accuracy Rate', value: '96%', icon: Brain },
    { label: 'Model Size', value: '15MB', icon: Cpu },
    { label: 'Processing Time', value: '<2s', icon: Smartphone },
  ];

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-orange-500 via-amber-500 to-green-600 text-white">
      <div className="absolute inset-0 bg-black/10"></div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            GrainPalette
          </h1>
          <p className="text-xl md:text-2xl mb-4 opacity-90 font-light">
            A Deep Learning Odyssey In Rice Type Classification
          </p>
          <p className="text-lg md:text-xl opacity-80 max-w-3xl mx-auto mb-12">
            Harness the power of Transfer Learning to identify and classify different rice varieties 
            with cutting-edge computer vision technology
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => setActiveSection('classify')}
              className="group bg-white text-orange-600 px-8 py-4 rounded-xl font-semibold text-lg transition-all duration-300 hover:shadow-2xl hover:-translate-y-1 flex items-center justify-center space-x-2"
            >
              <Image className="w-5 h-5" />
              <span>Try Classification</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            
            <button
              onClick={() => setActiveSection('guide')}
              className="group bg-white/20 backdrop-blur-sm border border-white/30 px-8 py-4 rounded-xl font-semibold text-lg transition-all duration-300 hover:bg-white/30 flex items-center justify-center space-x-2"
            >
              <Brain className="w-5 h-5" />
              <span>View Project Guide</span>
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div
                key={index}
                className="text-center group cursor-pointer"
              >
                <div className="w-16 h-16 mx-auto mb-4 bg-white/20 rounded-2xl flex items-center justify-center group-hover:bg-white/30 transition-all duration-300 group-hover:scale-110">
                  <Icon className="w-8 h-8" />
                </div>
                <div className="text-3xl font-bold mb-2">{stat.value}</div>
                <div className="text-sm opacity-80">{stat.label}</div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Hero;