import React from 'react';
import { CheckCircle, Clock, BookOpen, Target, Workflow, Building } from 'lucide-react';

const ProjectGuide: React.FC = () => {
  const guideItems = [
    {
      title: 'Prerequisites',
      icon: CheckCircle,
      description: 'Python, TensorFlow, Basic ML Knowledge',
      color: 'from-blue-500 to-blue-600',
    },
    {
      title: 'Prior Knowledge',
      icon: BookOpen,
      description: 'CNN, Transfer Learning, Image Processing',
      color: 'from-purple-500 to-purple-600',
    },
    {
      title: 'Project Objectives',
      icon: Target,
      description: 'Build accurate rice classification system',
      color: 'from-green-500 to-green-600',
    },
    {
      title: 'Project Flow',
      icon: Workflow,
      description: 'Data → Preprocessing → Model → Evaluation',
      color: 'from-orange-500 to-orange-600',
    },
    {
      title: 'Project Structure',
      icon: Building,
      description: 'Organized codebase with clear modules',
      color: 'from-red-500 to-red-600',
    },
    {
      title: 'Duration',
      icon: Clock,
      description: '2-3 weeks for complete implementation',
      color: 'from-teal-500 to-teal-600',
    },
  ];

  return (
    <section className="py-20 bg-white/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Project Overview
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            A comprehensive guide to building a state-of-the-art rice classification system 
            using deep learning and transfer learning techniques
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {guideItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={index}
                className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-gray-100"
              >
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-r ${item.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className="w-8 h-8 text-white" />
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {item.title}
                </h3>
                
                <p className="text-gray-600 leading-relaxed">
                  {item.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default ProjectGuide;