import React, { useState } from 'react';
import { Database, Image, Brain, Save, Smartphone, ChevronRight, Play, CheckCircle } from 'lucide-react';

const ProjectSteps: React.FC = () => {
  const [expandedStep, setExpandedStep] = useState<number | null>(null);

  const steps = [
    {
      id: 1,
      title: 'Data Collection',
      icon: Database,
      color: 'from-blue-500 to-blue-600',
      description: 'Gather diverse rice grain images from multiple sources',
      details: [
        'Collect 5,000+ images across 12 rice varieties',
        'Ensure balanced dataset with equal representation',
        'Include various lighting conditions and angles',
        'Validate image quality and labeling accuracy'
      ],
      code: `# Data collection script
import os
import requests
from PIL import Image

def collect_rice_images():
    rice_types = ['basmati', 'jasmine', 'arborio', ...]
    for rice_type in rice_types:
        # Download and organize images
        pass`
    },
    {
      id: 2,
      title: 'Image Preprocessing',
      icon: Image,
      color: 'from-purple-500 to-purple-600',
      description: 'Prepare and augment images for optimal model training',
      details: [
        'Resize images to 224x224 pixels',
        'Apply data augmentation techniques',
        'Normalize pixel values',
        'Split into training, validation, and test sets'
      ],
      code: `# Image preprocessing
from tensorflow.keras.preprocessing.image import ImageDataGenerator

datagen = ImageDataGenerator(
    rescale=1./255,
    rotation_range=20,
    width_shift_range=0.2,
    height_shift_range=0.2,
    horizontal_flip=True
)`
    },
    {
      id: 3,
      title: 'Model Building',
      icon: Brain,
      color: 'from-green-500 to-green-600',
      description: 'Implement transfer learning with pre-trained CNN models',
      details: [
        'Use pre-trained ResNet50 as base model',
        'Add custom classification layers',
        'Implement fine-tuning strategy',
        'Optimize hyperparameters'
      ],
      code: `# Transfer learning model
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D

base_model = ResNet50(weights='imagenet', include_top=False)
x = GlobalAveragePooling2D()(base_model.output)
predictions = Dense(12, activation='softmax')(x)`
    },
    {
      id: 4,
      title: 'Save The Model',
      icon: Save,
      color: 'from-orange-500 to-orange-600',
      description: 'Export trained model for deployment and inference',
      details: [
        'Save model in TensorFlow SavedModel format',
        'Convert to TensorFlow Lite for mobile deployment',
        'Create model metadata and documentation',
        'Validate model integrity'
      ],
      code: `# Model saving
model.save('rice_classifier_model')

# Convert to TensorFlow Lite
converter = tf.lite.TFLiteConverter.from_saved_model('rice_classifier_model')
tflite_model = converter.convert()`
    },
    {
      id: 5,
      title: 'Application Building',
      icon: Smartphone,
      color: 'from-red-500 to-red-600',
      description: 'Create user-friendly interface for rice classification',
      details: [
        'Build responsive web application',
        'Implement real-time image upload and processing',
        'Display classification results with confidence scores',
        'Add educational content about rice varieties'
      ],
      code: `// React application
const classifyRice = async (imageFile) => {
  const formData = new FormData();
  formData.append('image', imageFile);
  
  const response = await fetch('/api/classify', {
    method: 'POST',
    body: formData
  });
  
  return response.json();
};`
    }
  ];

  return (
    <section className="py-12 min-h-screen bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Project Implementation Guide
          </h1>
          <p className="text-xl text-gray-600">
            Step-by-step guide to building the rice classification system
          </p>
        </div>

        <div className="space-y-6">
          {steps.map((step, index) => {
            const Icon = step.icon;
            const isExpanded = expandedStep === step.id;
            const isCompleted = index < 3; // Mock completion status

            return (
              <div
                key={step.id}
                className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300"
              >
                <div
                  className="p-6 cursor-pointer"
                  onClick={() => setExpandedStep(isExpanded ? null : step.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${step.color} flex items-center justify-center relative`}>
                        <Icon className="w-6 h-6 text-white" />
                        {isCompleted && (
                          <div className="absolute -top-1 -right-1 w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
                            <CheckCircle className="w-3 h-3 text-white" />
                          </div>
                        )}
                      </div>
                      
                      <div>
                        <div className="flex items-center space-x-3">
                          <h3 className="text-xl font-bold text-gray-900">
                            {step.id}: {step.title}
                          </h3>
                          {isCompleted && (
                            <span className="px-2 py-1 bg-green-100 text-green-700 text-xs font-medium rounded-full">
                              Completed
                            </span>
                          )}
                        </div>
                        <p className="text-gray-600 mt-1">{step.description}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <button className={`p-2 rounded-lg bg-gradient-to-r ${step.color} text-white hover:shadow-lg transition-all duration-200`}>
                        <Play className="w-4 h-4" />
                      </button>
                      <ChevronRight
                        className={`w-5 h-5 text-gray-400 transition-transform duration-200 ${
                          isExpanded ? 'rotate-90' : ''
                        }`}
                      />
                    </div>
                  </div>
                </div>

                {isExpanded && (
                  <div className="px-6 pb-6 border-t border-gray-100">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-3">Key Tasks:</h4>
                        <ul className="space-y-2">
                          {step.details.map((detail, idx) => (
                            <li key={idx} className="flex items-start space-x-2">
                              <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                              <span className="text-gray-600 text-sm">{detail}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-3">Code Example:</h4>
                        <div className="bg-gray-900 rounded-lg p-4 overflow-x-auto">
                          <pre className="text-sm text-gray-300">
                            <code>{step.code}</code>
                          </pre>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default ProjectSteps;